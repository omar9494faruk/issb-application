<?php
session_start()
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Consultation</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
        <div class="header-part">
            <div class="logo-area">
            <a href="index.php"><img src="images/logo.png" alt="Logo" srcset=""></a>
                <div class="text-area">
                    <p>Lighting Your Way To Success</p>
                </div>
            </div>
            <div class="menu-area">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="blogs">Blogs</a></li>
                </ul>
            </div>
            <div class="profile-area">
            </div>
        </div>
    <h2>For Personal Consultation, please contact in this number {} over whatsappp.</h2>

    
</body>
</html>