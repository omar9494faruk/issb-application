<?php
session_start()
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WISHES</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
        <div class="header-part">
            <div class="logo-area">
            <a href="index.php"><img src="images/logo.png" alt="Logo" srcset=""></a>
                <div class="text-area">
                    <p>Lighting Your Way To Success</p>
                </div>
            </div>
            <div class="menu-area">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="blogs">Blogs</a></li>
                </ul>
            </div>
            <div class="profile-area">
            </div>
        </div>
    <h2>The test has ended. Hope you had a great test. Now to give other tests <a href="index.php">CLICK HERE</a>. This will take you to home page and from there you can move on to other tests.</h2>

    
</body>
</html>