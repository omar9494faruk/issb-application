<div class="admin-header">
        <ul>
            <li><a href="update.php">Main</a></li>
            <li><a href="wat-update.php">WAT</a></li>
            <li><a href="ppdt-update.php">PPDT</a></li>
            <li><a href="tat-update.php">TAT</a></li>
            <li><a href="cs-update.php">COMP STORY</a></li>
            <li><a href="fb-update.php">COMP SENT</a></li>
            <li><a href="essay-update.php">ESSAY</a></li>
            <li><a href="blog-update.php">BLOG</a></li>
            <li><a href="iq-update.php">IQ</a></li>
            <li><a href="AFprelims-update.php">BAFA</a></li>
            <li><a href="pArmy.php">Army Preli</a></li>
            <li><a href="pNavy-update.php">Navy Preli</a></li>
        </ul>
    </div>