<?php
session_start();
// if ($_SESSION['adminLoggedIn']='yes') {
    
//     header("Location: ../index.php");
//     exit();
// }
// if (!isset($_SESSION['username'])) {
    
//     header("Location: ../index.php");
//     exit();
// }
